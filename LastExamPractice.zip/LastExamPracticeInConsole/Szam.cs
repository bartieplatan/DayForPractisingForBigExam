﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LastExamPracticeInConsole
{
    class Szam
    {
        public int nySzam;
        public int db;

        public Szam(int nySzam, int db)
        {
            this.nySzam = nySzam;
            this.db = db;
        }
    }
}