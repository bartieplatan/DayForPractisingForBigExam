﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class Order
    {
        public string sorSzam;
        public string fnev;
        public int ar;
        public int kedv;
        public int fizetendo;

        public Order(string sorSzam, string fnev, string a, string ked)
        {
            this.sorSzam = sorSzam;
            this.fnev = fnev;
            this.ar = int.Parse(a);
            this.kedv = int.Parse(ked);
            this.fizetendo = ar - kedv;
        }
    }
}
